# Jogo desenvolvido para a Ofina Aprendendo Através de Jogos do projeto Mermãs Digitais 2022

![ingame2](https://user-images.githubusercontent.com/43351859/193393497-5b05d600-12b1-4bfb-9bce-ce0350d1f7f2.png)
